#include <arpa/inet.h>
#include <algorithm>
#include <cstdlib>
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

namespace {
constexpr std::size_t CHUNK_BYTES = 16;
constexpr std::size_t MAX_MESSAGE_BYTES = 65536;

struct Config {
    std::string host;
    std::string port = "5000";
    unsigned long long bps = 0;  // 0 means unlimited application throughput
};

void usage(const char* exe) {
    std::cout << "Usage: " << exe << " --host PC_IP [--port 5000] [--bps 2000]\n"
              << "  --bps 0: no application-level rate limit (default)\n"
              << "  --bps N: pace *framed application bytes* to N bits/s\n"
              << "  /quit: stop the sender\n";
}

unsigned long long parse_unsigned(const std::string& v) {
    if (v.empty() || v[0] == '-') throw std::runtime_error("Invalid number: " + v);
    std::size_t pos = 0;
    auto n = std::stoull(v, &pos);
    if (pos != v.size()) throw std::runtime_error("Invalid number: " + v);
    return n;
}

Config parse_args(int argc, char** argv) {
    Config c;
    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") { usage(argv[0]); std::exit(0); }
        if ((arg == "--host" || arg == "--port" || arg == "--bps") && i + 1 < argc) {
            std::string v = argv[++i];
            if (arg == "--host") c.host = v;
            else if (arg == "--port") {
                auto n = parse_unsigned(v);
                if (n == 0 || n > 65535) throw std::runtime_error("Port must be in 1..65535");
                c.port = v;
            } else c.bps = parse_unsigned(v);
        } else {
            throw std::runtime_error("Unknown/missing argument: " + arg);
        }
    }
    if (c.host.empty()) throw std::runtime_error("Required option: --host PC_IP");
    return c;
}

int connect_to(const Config& c) {
    struct addrinfo hints {};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    struct addrinfo* result = nullptr;
    int rc = getaddrinfo(c.host.c_str(), c.port.c_str(), &hints, &result);
    if (rc != 0) throw std::runtime_error(std::string("getaddrinfo: ") + gai_strerror(rc));
    int sock = -1;
    for (auto* it = result; it != nullptr; it = it->ai_next) {
        sock = socket(it->ai_family, it->ai_socktype, it->ai_protocol);
        if (sock < 0) continue;
        if (connect(sock, it->ai_addr, it->ai_addrlen) == 0) break;
        close(sock);
        sock = -1;
    }
    freeaddrinfo(result);
    if (sock < 0) throw std::runtime_error("Cannot connect to " + c.host + ":" + c.port + "; check PC IP, server and firewall");
    return sock;
}

class Pacer {
public:
    explicit Pacer(unsigned long long bps) : bps_(bps), next_(Clock::now()) {}

    void before_sending(std::size_t byte_count) {
        if (bps_ == 0) return;
        using Seconds = std::chrono::duration<double>;
        auto now = Clock::now();
        if (next_ < now) next_ = now;
        const double seconds = static_cast<double>(byte_count) * 8.0 / static_cast<double>(bps_);
        next_ += std::chrono::duration_cast<Clock::duration>(Seconds(seconds));
        std::this_thread::sleep_until(next_);
    }

private:
    using Clock = std::chrono::steady_clock;
    unsigned long long bps_;
    Clock::time_point next_;
};

void send_all(int fd, const std::uint8_t* bytes, std::size_t count) {
    std::size_t sent = 0;
    while (sent < count) {
        ssize_t n = send(fd, bytes + sent, count - sent, MSG_NOSIGNAL);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) throw std::runtime_error(std::string("send failed: ") + std::strerror(errno));
        sent += static_cast<std::size_t>(n);
    }
}

void send_paced(int fd, const std::uint8_t* data, std::size_t len, Pacer& pacer) {
    for (std::size_t offset = 0; offset < len; offset += CHUNK_BYTES) {
        auto n = std::min(CHUNK_BYTES, len - offset);
        pacer.before_sending(n);
        send_all(fd, data + offset, n);
    }
}

void send_control_frame(int fd, const std::string& text) {
    std::uint32_t network_size = htonl(static_cast<std::uint32_t>(text.size()));
    send_all(fd, reinterpret_cast<const std::uint8_t*>(&network_size), sizeof(network_size));
    send_all(fd, reinterpret_cast<const std::uint8_t*>(text.data()), text.size());
}
} // namespace

int main(int argc, char** argv) {
    int sock = -1;
    try {
        auto cfg = parse_args(argc, argv);
        std::cout << "[INFO] Connecting to PC " << cfg.host << ":" << cfg.port << "...\n";
        sock = connect_to(cfg);
        std::cout << "[OK] TCP connected.\n"
                  << "[INFO] Application rate limit: "
                  << (cfg.bps == 0 ? std::string("OFF") : std::to_string(cfg.bps) + " bps")
                  << "\n[INFO] Framing: 4-byte length + UTF-8 text; 16-byte paced writes.\n"
                  << "Enter a text line. /quit to exit.\n\n";

        send_control_frame(sock, "@VENTUNO/1 CONFIG " + std::to_string(cfg.bps));

        Pacer pacer(cfg.bps);
        std::string line;
        while (true) {
            std::cout << "TX> " << std::flush;
            if (!std::getline(std::cin, line) || line == "/quit") break;
            if (line.empty()) continue;
            if (line.size() > MAX_MESSAGE_BYTES) {
                std::cerr << "[WARN] Message too long (max " << MAX_MESSAGE_BYTES << " bytes).\n";
                continue;
            }

            std::uint32_t network_size = htonl(static_cast<std::uint32_t>(line.size()));
            auto start = std::chrono::steady_clock::now();
            send_paced(sock, reinterpret_cast<const std::uint8_t*>(&network_size), sizeof(network_size), pacer);
            send_paced(sock, reinterpret_cast<const std::uint8_t*>(line.data()), line.size(), pacer);
            auto end = std::chrono::steady_clock::now();
            double elapsed = std::chrono::duration<double>(end - start).count();
            auto elapsed_ns = std::max<std::int64_t>(
                1, std::chrono::duration_cast<std::chrono::nanoseconds>(end - start).count());
            const auto app_bytes = line.size() + sizeof(network_size);
            send_control_frame(sock, "@VENTUNO/1 STATS " + std::to_string(cfg.bps) + " "
                + std::to_string(line.size()) + " " + std::to_string(app_bytes) + " "
                + std::to_string(elapsed_ns));
            std::cout << "[TX] payload=" << line.size()
                      << " B, framed=" << app_bytes
                      << " B, elapsed=" << elapsed
                      << " s, app_rate=" << (elapsed > 0 ? app_bytes * 8.0 / elapsed : 0)
                      << " bps\n";
        }
        shutdown(sock, SHUT_RDWR);
        close(sock);
        return 0;
    } catch (const std::exception& e) {
        if (sock >= 0) close(sock);
        std::cerr << "[ERROR] " << e.what() << "\n";
        return 1;
    }
}
