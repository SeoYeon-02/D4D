# VENTUNO Q → Ubuntu PC: Wi-Fi semantic text demo (C++17)

The VENTUNO Q sends UTF-8 text read from its terminal to an Ubuntu PC over a TCP connection on the same Wi-Fi/LAN. The receiver displays messages. No Bluetooth, Python, third-party C++ library, or root privilege is needed to build or run.

## Build on **both** Ubuntu PC and VENTUNO Q

```bash
sudo apt update
sudo apt install -y build-essential cmake
cd ventuno_wifi_semantic
cmake -S . -B build
cmake --build build -j
```

## PC: find IPv4 and run receiver FIRST

```bash
hostname -I
./build/wifi_receiver --port 5000 --http-port 8080
```

For the compact single-screen dashboard, build and run the separate receiver.
The original `wifi_receiver.cpp` and executable remain unchanged:

```bash
./build/wifi_receiver_compact --port 5000 --http-port 8080
```

Open `http://<PC_WIFI_IP>:8080` in a browser to view the Ventuno Q connection
state, latest VLM output, receive history, message count, and optional keyword
warnings. Warning keywords are entered as a comma-separated list in the browser.
The server keeps the latest 100 messages by default; use `--history N` to change
the limit. The dashboard also shows the sender's configured `--bps` value, the
measured framed-message rate, a recent speed graph, and average/peak results
grouped by configured rate. Rebuild both sender and receiver after updating;
older senders still deliver text but do not provide speed statistics.

The same TCP port also accepts an IMU board concurrently. The dashboard uses an
offline local X/Y minimap with the origin, recent trajectory, current position,
and yaw direction. It also shows roll, pitch, yaw, and the latest receive
time/sample count. Until real hardware is available, run the simulator:

```bash
./build_gui/imu_sender --host 127.0.0.1 --port 5000 --device imu-sim-01
```

For the NU-40 odometry receiver in `../IMU/imu_odom_viewer_wifi.py`, forward real
USB serial data to this dashboard with:

```bash
python3 ../IMU/imu_odom_viewer_wifi.py \
  --port /dev/ttyACM0 --baud 115200 \
  --gui-host 192.168.0.123 --gui-port 5000 --gui-only
```

For BLE UART, replace the serial options with `--ble` (and optionally
`--name NU40-ODOM`). The GUI receiver must be running first. Replace the host
with the GUI PC's Wi-Fi/LAN IPv4 address; use `127.0.0.1` only when the IMU
script and GUI receiver run on the same PC. The bridge sends X/Y and
roll/pitch/yaw from each `ODO,...` sample. The current ODO stream has no Z,
acceleration, or angular-velocity fields, so those GUI protocol values are sent
as zero.

An actual board should first send `@IMU/1 CONFIG <device-id>` as a normal framed
text message, followed by framed samples in this format:

```text
@IMU/1 DATA x y z roll pitch yaw ax ay az gx gy gz
```

Positions use metres, attitude uses degrees, acceleration uses m/s², and angular
velocity uses degrees/s. On the minimap, positive X points right and positive Y
points up. IMU-only position is dead reckoning and will drift; use
GPS, UWB, visual odometry or another external reference when absolute position
is required.

Use the PC's Wi-Fi/LAN address, **not** `127.0.0.1`. If UFW is enabled, allow TCP port 5000 from the board and HTTP port 8080 from dashboard viewers. For example: `sudo ufw allow from 192.168.0.30 to any port 5000 proto tcp`. Only use on a trusted LAN; the receiver and dashboard have no authentication or encryption.

## Board: connect and send

```bash
./build/wifi_sender --host 192.168.0.123 --port 5000 --bps 2000
```

Replace `192.168.0.123` with your **PC** IP.

Type text at `TX>` and press Enter. `/quit` exits. Example:

```text
TX> PERSON 3 MOVE NORTH SECTOR B4
[TX] payload=29 B, framed=33 B, elapsed=... s, app_rate=... bps
```

PC shows `[RX] 29 bytes: PERSON 3 MOVE NORTH SECTOR B4`.

## Rate control

`--bps 0` (the default): no application-level pacing. `--bps 500`, `1000`, `2000`, `5000`, `10000` pace transmitted framed bytes. Each message uses 4 bytes for a big-endian length prefix followed by UTF-8 payload. The sender splits writes into 16-byte chunks, waits the corresponding time **before** each chunk, and accounts for the 4-byte prefix.

**This is application payload rate limiting, not an actual Wi-Fi PHY rate change or kernel traffic shaping.** Traffic on the air includes extra TCP/IP, link-layer, retransmission, acknowledgments and management overhead, so a 2000 bps setting is not a 2000 bps RF bit rate. For controlled physical-network-emulation experiments, use Linux `tc` separately and measure packet traffic with `tcpdump`/Wireshark.

TCP provides ordered reliable delivery. Therefore these tests demonstrate semantic payload reduction and *app-layer throughput limitation*, not resilience to actual packet loss/jamming. Later, you can add UDP with sequence numbers and drop/loss emulation as a separate experiment.

Security: the receiver listens on all IPv4 interfaces; run only on trusted networks, constrain its firewall to the board IP, and stop the server when finished. The demo does not encrypt messages at the application layer (Wi-Fi security depends on the access point/network).

## all_pipeline result bridge

`pipeline_gui_bridge.py` watches the JSON output produced by `all_pipeline` and
forwards each changed result through the existing framed TCP protocol. It shows
the YOLO detection count, mine status, class/confidence, VLM semantic fields,
schema warning, and inference latency in the GUI without changing the pipeline.

Run the receiver on the GUI PC first:

```bash
./build_gui/wifi_receiver_compact --port 5000 --http-port 8080
```

Then run the bridge on the PC or board that has the pipeline output. A directory
is watched continuously; `tracker_state.json` is ignored:

```bash
python3 pipeline_gui_bridge.py \
  --host 223.195.36.45 \
  --port 5000 \
  --path /path/to/all_pipeline/runtime_output
```

For a single result file and immediate exit, add `--once`:

```bash
python3 pipeline_gui_bridge.py --host 223.195.36.45 --port 5000 \
  --path /path/to/result.json --once
```

## Troubleshooting

- `connect failed`: check both hosts are on the same network, find PC IP (`hostname -I`), confirm receiver running before sender, and check firewall/guest isolation.
- `bind: Address already in use`: port 5000 is already occupied; change `--port` on both sides.
- Board prompt remains idle: this is expected until you type text.
- Send from an SSH session on the board, if desired.
