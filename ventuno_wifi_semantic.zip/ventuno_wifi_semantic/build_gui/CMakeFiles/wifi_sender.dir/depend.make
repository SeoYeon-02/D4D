# Empty dependencies file for wifi_sender.
# This may be replaced when dependencies are built.
