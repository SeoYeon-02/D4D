file(REMOVE_RECURSE
  "CMakeFiles/wifi_sender.dir/wifi_sender.cpp.o"
  "CMakeFiles/wifi_sender.dir/wifi_sender.cpp.o.d"
  "wifi_sender"
  "wifi_sender.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wifi_sender.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
