# Empty dependencies file for wifi_receiver_compact.
# This may be replaced when dependencies are built.
