
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/hdd/sy/D4D/ventuno_wifi_semantic/wifi_receiver_compact.cpp" "CMakeFiles/wifi_receiver_compact.dir/wifi_receiver_compact.cpp.o" "gcc" "CMakeFiles/wifi_receiver_compact.dir/wifi_receiver_compact.cpp.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
