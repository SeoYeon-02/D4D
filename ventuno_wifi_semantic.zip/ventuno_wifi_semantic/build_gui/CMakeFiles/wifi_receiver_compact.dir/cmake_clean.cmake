file(REMOVE_RECURSE
  "CMakeFiles/wifi_receiver_compact.dir/wifi_receiver_compact.cpp.o"
  "CMakeFiles/wifi_receiver_compact.dir/wifi_receiver_compact.cpp.o.d"
  "wifi_receiver_compact"
  "wifi_receiver_compact.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wifi_receiver_compact.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
