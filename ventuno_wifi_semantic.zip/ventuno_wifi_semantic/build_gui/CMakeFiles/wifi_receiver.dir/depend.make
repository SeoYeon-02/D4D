# Empty dependencies file for wifi_receiver.
# This may be replaced when dependencies are built.
