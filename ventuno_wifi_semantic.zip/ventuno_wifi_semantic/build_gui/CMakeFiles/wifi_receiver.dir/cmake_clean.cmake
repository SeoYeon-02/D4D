file(REMOVE_RECURSE
  "CMakeFiles/wifi_receiver.dir/wifi_receiver.cpp.o"
  "CMakeFiles/wifi_receiver.dir/wifi_receiver.cpp.o.d"
  "wifi_receiver"
  "wifi_receiver.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/wifi_receiver.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
