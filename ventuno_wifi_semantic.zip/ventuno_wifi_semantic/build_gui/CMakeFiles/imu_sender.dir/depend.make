# Empty dependencies file for imu_sender.
# This may be replaced when dependencies are built.
