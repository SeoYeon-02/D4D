file(REMOVE_RECURSE
  "CMakeFiles/imu_sender.dir/imu_sender.cpp.o"
  "CMakeFiles/imu_sender.dir/imu_sender.cpp.o.d"
  "imu_sender"
  "imu_sender.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/imu_sender.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
