#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>

namespace {
constexpr double PI = 3.14159265358979323846;

struct Config {
    std::string host;
    std::string port = "5000";
    std::string device_id = "imu-board-01";
    unsigned long long interval_ms = 200;
    unsigned long long count = 0;
};

unsigned long long number(const std::string& value, const std::string& option) {
    std::size_t pos = 0;
    auto result = std::stoull(value, &pos);
    if (pos != value.size()) throw std::runtime_error("Invalid " + option);
    return result;
}

Config parse_args(int argc, char** argv) {
    Config config;
    for (int i = 1; i < argc; ++i) {
        std::string option = argv[i];
        if (option == "--help" || option == "-h") {
            std::cout << "Usage: " << argv[0]
                      << " --host SERVER_IP [--port 5000] [--device imu-board-01]"
                         " [--interval-ms 200] [--count 0]\n";
            std::exit(0);
        }
        if ((option == "--host" || option == "--port" || option == "--device" ||
             option == "--interval-ms" || option == "--count") && i + 1 < argc) {
            std::string value = argv[++i];
            if (option == "--host") config.host = value;
            else if (option == "--port") config.port = value;
            else if (option == "--device") config.device_id = value;
            else if (option == "--interval-ms") config.interval_ms = number(value, option);
            else config.count = number(value, option);
        } else {
            throw std::runtime_error("Unknown/missing option: " + option);
        }
    }
    if (config.host.empty()) throw std::runtime_error("Required option: --host SERVER_IP");
    if (config.device_id.empty() || config.device_id.size() > 64) throw std::runtime_error("Invalid device ID");
    auto port = number(config.port, "--port");
    if (port == 0 || port > 65535) throw std::runtime_error("Port must be in 1..65535");
    if (config.interval_ms < 20 || config.interval_ms > 60000) {
        throw std::runtime_error("--interval-ms must be in 20..60000");
    }
    return config;
}

int connect_to(const Config& config) {
    addrinfo hints {};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* result = nullptr;
    int rc = getaddrinfo(config.host.c_str(), config.port.c_str(), &hints, &result);
    if (rc != 0) throw std::runtime_error(std::string("getaddrinfo: ") + gai_strerror(rc));
    int socket_fd = -1;
    for (auto* item = result; item; item = item->ai_next) {
        socket_fd = socket(item->ai_family, item->ai_socktype, item->ai_protocol);
        if (socket_fd >= 0 && connect(socket_fd, item->ai_addr, item->ai_addrlen) == 0) break;
        if (socket_fd >= 0) close(socket_fd);
        socket_fd = -1;
    }
    freeaddrinfo(result);
    if (socket_fd < 0) throw std::runtime_error("Cannot connect to server");
    return socket_fd;
}

void send_all(int socket_fd, const void* data, std::size_t size) {
    auto* bytes = static_cast<const std::uint8_t*>(data);
    std::size_t sent = 0;
    while (sent < size) {
        ssize_t count = send(socket_fd, bytes + sent, size - sent, MSG_NOSIGNAL);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) throw std::runtime_error(std::string("send: ") + std::strerror(errno));
        sent += static_cast<std::size_t>(count);
    }
}

void send_frame(int socket_fd, const std::string& text) {
    std::uint32_t size = htonl(static_cast<std::uint32_t>(text.size()));
    send_all(socket_fd, &size, sizeof(size));
    send_all(socket_fd, text.data(), text.size());
}
} // namespace

int main(int argc, char** argv) {
    int socket_fd = -1;
    try {
        Config config = parse_args(argc, argv);
        socket_fd = connect_to(config);
        send_frame(socket_fd, "@IMU/1 CONFIG " + config.device_id);
        std::cout << "[OK] IMU simulator connected to " << config.host << ':' << config.port
                  << " as " << config.device_id << "\n";

        auto next = std::chrono::steady_clock::now();
        for (unsigned long long index = 0; config.count == 0 || index < config.count; ++index) {
            double t = static_cast<double>(index) * static_cast<double>(config.interval_ms) / 1000.0;
            double x = 5.0 * std::cos(t * 0.25);
            double y = 3.0 * std::sin(t * 0.50);
            double z = 0.15 * std::sin(t * 0.70);
            double dx = -1.25 * std::sin(t * 0.25);
            double dy = 1.50 * std::cos(t * 0.50);
            double yaw = std::atan2(dy, dx) * 180.0 / PI;
            if (yaw < 0) yaw += 360.0;
            double roll = 4.0 * std::sin(t * 0.8);
            double pitch = 3.0 * std::cos(t * 0.6);
            double ax = -0.3125 * std::cos(t * 0.25);
            double ay = -0.75 * std::sin(t * 0.50);
            double az = 9.81 - 0.0735 * std::sin(t * 0.70);
            double gx = 3.2 * std::cos(t * 0.8);
            double gy = -1.8 * std::sin(t * 0.6);
            double gz = 8.0 * std::sin(t * 0.3);

            std::ostringstream message;
            message << std::fixed << std::setprecision(5) << "@IMU/1 DATA "
                    << x << ' ' << y << ' ' << z << ' '
                    << roll << ' ' << pitch << ' ' << yaw << ' '
                    << ax << ' ' << ay << ' ' << az << ' '
                    << gx << ' ' << gy << ' ' << gz;
            send_frame(socket_fd, message.str());
            if (index % 10 == 0) std::cout << "[IMU] x=" << x << " y=" << y << " yaw=" << yaw << "\n";
            next += std::chrono::milliseconds(config.interval_ms);
            std::this_thread::sleep_until(next);
        }
        shutdown(socket_fd, SHUT_RDWR);
        close(socket_fd);
        return 0;
    } catch (const std::exception& error) {
        if (socket_fd >= 0) close(socket_fd);
        std::cerr << "[ERROR] " << error.what() << "\n";
        return 1;
    }
}
