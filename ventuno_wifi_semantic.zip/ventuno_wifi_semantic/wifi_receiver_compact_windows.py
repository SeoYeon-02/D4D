#!/usr/bin/env python3
"""Windows-native receiver that reuses the exact GUI embedded in wifi_receiver_compact.cpp."""

from __future__ import annotations

import argparse
import json
import re
import socket
import socketserver
import struct
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

MAX_MESSAGE_BYTES = 65536


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--http-port", type=int, default=8080)
    parser.add_argument("--history", type=int, default=100)
    parser.add_argument("--source", type=Path, default=Path(__file__).with_name("wifi_receiver_compact.cpp"),
                        help="Path to the original wifi_receiver_compact.cpp")
    parser.add_argument("--dashboard", type=Path,
                        default=Path(__file__).with_name("ventuno_mission_dashboard.html"),
                        help="Optional dashboard HTML; falls back to the original embedded GUI")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535 or not 1 <= args.http_port <= 65535:
        parser.error("ports must be in 1..65535")
    if args.port == args.http_port:
        parser.error("TCP port and HTTP port must be different")
    if not 1 <= args.history <= 10000:
        parser.error("--history must be in 1..10000")
    if not args.source.is_file():
        parser.error(f"original receiver source not found: {args.source}")
    return args


def dashboard_html(source: Path, dashboard: Path) -> bytes:
    if dashboard.is_file():
        return dashboard.read_bytes()
    text = source.read_text(encoding="utf-8")
    match = re.search(r'const char\* DASHBOARD_HTML\s*=\s*R"HTML\((.*?)\)HTML";', text, re.S)
    if not match:
        raise RuntimeError(f"DASHBOARD_HTML not found in {source}")
    return match.group(1).encode("utf-8")


class State:
    def __init__(self, limit: int) -> None:
        self.lock = threading.Lock()
        self.limit = limit
        self.connected = False
        self.peer = ""
        self.last_received = ""
        self.message_count = 0
        self.payload_total = 0
        self.current_target_bps = 0
        self.last_actual_bps = 0.0
        self.messages: deque[dict[str, Any]] = deque(maxlen=limit)
        self.bands: dict[int, dict[str, float | int]] = {}
        self.imu_connected = False
        self.imu_peer = ""
        self.imu_device_id = ""
        self.imu_last_received = ""
        self.imu_sample_count = 0
        self.imu_latest = {k: 0.0 for k in ("x y z roll pitch yaw ax ay az gx gy gz").split()}
        self.imu_origin_xy: tuple[float, float] | None = None
        self.imu_trail: deque[dict[str, Any]] = deque(maxlen=300)

    @staticmethod
    def now() -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S")

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            bands = [{"target_bps": target, "samples": row["samples"],
                      "average_bps": row["total"] / row["samples"] if row["samples"] else 0,
                      "peak_bps": row["peak"]} for target, row in sorted(self.bands.items())]
            return {"connected": self.connected, "peer": self.peer,
                    "last_received": self.last_received, "message_count": self.message_count,
                    "payload_total": self.payload_total, "current_target_bps": self.current_target_bps,
                    "last_actual_bps": self.last_actual_bps, "messages": list(reversed(self.messages)),
                    "bands": bands, "imu": {"connected": self.imu_connected,
                    "origin_lat": 37.55081, "origin_lon": 127.07423, "peer": self.imu_peer,
                    "device_id": self.imu_device_id, "last_received": self.imu_last_received,
                    "sample_count": self.imu_sample_count, "latest": dict(self.imu_latest),
                    "trail": list(self.imu_trail)}}


def recv_exact(sock: socket.socket, length: int) -> bytes | None:
    data = bytearray()
    while len(data) < length:
        block = sock.recv(length - len(data))
        if not block:
            return None
        data.extend(block)
    return bytes(data)


def control(state: State, text: str, peer: str) -> str | None:
    if text.startswith("@VENTUNO/1 CONFIG "):
        try:
            target = int(text.removeprefix("@VENTUNO/1 CONFIG "))
        except ValueError:
            return "vlm"
        with state.lock:
            state.connected, state.peer, state.current_target_bps = True, peer, target
            state.last_actual_bps = 0.0
        return "vlm"
    if text.startswith("@VENTUNO/1 STATS "):
        try:
            target, payload, framed, elapsed = map(int, text.removeprefix("@VENTUNO/1 STATS ").split())
            if framed != payload + 4 or elapsed <= 0:
                return "vlm"
            actual = framed * 8 * 1_000_000_000 / elapsed
        except ValueError:
            return "vlm"
        with state.lock:
            state.current_target_bps, state.last_actual_bps = target, actual
            row = state.bands.setdefault(target, {"samples": 0, "total": 0.0, "peak": 0.0})
            row["samples"] += 1; row["total"] += actual; row["peak"] = max(row["peak"], actual)
            if state.messages and len(state.messages[-1]["text"].encode("utf-8")) == payload:
                state.messages[-1].update(target_bps=target, actual_bps=actual, elapsed_ms=elapsed / 1_000_000)
        return "vlm"
    if text.startswith("@IMU/1 CONFIG "):
        device = text.removeprefix("@IMU/1 CONFIG ")
        with state.lock:
            state.imu_connected, state.imu_peer, state.imu_device_id = True, peer, device
            state.imu_sample_count = 0
            state.imu_origin_xy = None
            state.imu_latest = {k: 0.0 for k in ("x y z roll pitch yaw ax ay az gx gy gz").split()}
            state.imu_trail.clear()
        return "imu"
    if text.startswith("@IMU/1 DATA "):
        try:
            values = list(map(float, text.removeprefix("@IMU/1 DATA ").split()))
            if len(values) != 12:
                return "imu"
        except ValueError:
            return "imu"
        names = "x y z roll pitch yaw ax ay az gx gy gz".split()
        with state.lock:
            state.imu_connected, state.imu_peer = True, peer
            if state.imu_origin_xy is None:
                state.imu_origin_xy = (values[0], values[1])
            origin_x, origin_y = state.imu_origin_xy
            relative_x, relative_y = values[0] - origin_x, values[1] - origin_y
            state.imu_sample_count += 1; state.imu_last_received = state.now()
            state.imu_latest = dict(zip(names, values))
            state.imu_latest["x"], state.imu_latest["y"] = relative_x, relative_y
            if state.imu_trail.maxlen and len(state.imu_trail) == state.imu_trail.maxlen:
                origin_point = state.imu_trail.popleft()
                state.imu_trail.popleft()
                state.imu_trail.appendleft(origin_point)
            state.imu_trail.append({"id": state.imu_sample_count, "x": relative_x, "y": relative_y,
                                    "yaw": values[5], "received_at": state.imu_last_received})
        return "imu"
    return None


class DataHandler(socketserver.BaseRequestHandler):
    state: State

    def handle(self) -> None:
        peer = f"{self.client_address[0]}:{self.client_address[1]}"; kind = "unknown"
        print(f"[INFO] New data connection from {peer}", flush=True)
        try:
            while True:
                header = recv_exact(self.request, 4)
                if header is None:
                    break
                size = struct.unpack("!I", header)[0]
                if size > MAX_MESSAGE_BYTES:
                    raise ValueError("Rejected oversized frame")
                payload = recv_exact(self.request, size)
                if payload is None:
                    break
                text = payload.decode("utf-8")
                identified = control(self.state, text, peer)
                if identified:
                    kind = identified; continue
                if kind == "unknown":
                    kind = "vlm"
                    with self.state.lock:
                        self.state.connected, self.state.peer = True, peer
                if kind == "vlm":
                    with self.state.lock:
                        self.state.message_count += 1; self.state.payload_total += size
                        self.state.last_received = self.state.now()
                        self.state.messages.append({"id": self.state.message_count,
                            "received_at": self.state.last_received, "text": text,
                            "target_bps": 0, "actual_bps": 0, "elapsed_ms": 0})
                    print(f"[VLM] {size} bytes: {text}", flush=True)
        except (OSError, UnicodeError, ValueError) as error:
            print(f"[WARN] Client {peer}: {error}", flush=True)
        finally:
            with self.state.lock:
                if kind == "vlm" and self.state.peer == peer:
                    self.state.connected, self.state.peer = False, ""
                if kind == "imu" and self.state.imu_peer == peer:
                    self.state.imu_connected, self.state.imu_peer = False, ""


def http_handler(state: State, html: bytes):
    class Handler(BaseHTTPRequestHandler):
        def reply(self, code: int, content_type: str, body: bytes) -> None:
            self.send_response(code); self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body))); self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff"); self.end_headers(); self.wfile.write(body)

        def do_GET(self) -> None:
            path = self.path.split("?", 1)[0]
            if path in ("/", "/index.html"):
                self.reply(200, "text/html; charset=utf-8", html)
            elif path == "/api/status":
                self.reply(200, "application/json; charset=utf-8",
                           json.dumps(state.snapshot(), ensure_ascii=False, separators=(",", ":")).encode())
            elif path == "/favicon.ico":
                self.reply(204, "image/x-icon", b"")
            else:
                self.reply(404, "text/plain; charset=utf-8", b"Not found\n")

        def log_message(self, _format: str, *_args: Any) -> None:
            pass
    return Handler


class ThreadedTCPServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main() -> int:
    args = arguments(); html = dashboard_html(args.source.resolve(), args.dashboard.resolve()); state = State(args.history)
    DataHandler.state = state
    tcp = ThreadedTCPServer(("0.0.0.0", args.port), DataHandler)
    http = ThreadingHTTPServer(("0.0.0.0", args.http_port), http_handler(state, html))
    threading.Thread(target=tcp.serve_forever, daemon=True).start()
    print("Windows PC Wi-Fi Semantic Receiver")
    print(f"[INFO] VLM + IMU TCP receiver: 0.0.0.0:{args.port}")
    print(f"[INFO] Dashboard: http://127.0.0.1:{args.http_port}")
    print("[INFO] Ctrl+C to stop.", flush=True)
    try:
        http.serve_forever()
    except KeyboardInterrupt:
        print("\n[INFO] stopped", flush=True)
    finally:
        http.server_close(); tcp.shutdown(); tcp.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
