#!/usr/bin/env python3
"""Calibrate Ventuno Q RGB/LWIR cameras from paired checkerboard images."""

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np


PATTERN = (7, 5)


def thermal_u8(raw):
    lo, hi = np.percentile(raw, (1, 99))
    base = np.clip((raw.astype(np.float32) - lo) * 255.0 / max(1.0, hi - lo), 0, 255).astype(np.uint8)
    return [base, cv2.createCLAHE(2.0, (4, 4)).apply(base), 255 - base]


def detect(gray_variants):
    flags = cv2.CALIB_CB_EXHAUSTIVE | cv2.CALIB_CB_ACCURACY
    for gray in gray_variants:
        ok, corners = cv2.findChessboardCornersSB(gray, PATTERN, flags)
        if ok:
            return corners.astype(np.float32)
    return None


def align_order(rgb, lwir):
    # A symmetric checkerboard has a 180-degree indexing ambiguity.
    score_same = np.dot(rgb[6, 0] - rgb[0, 0], lwir[6, 0] - lwir[0, 0])
    score_same += np.dot(rgb[28, 0] - rgb[0, 0], lwir[28, 0] - lwir[0, 0])
    score_flip = np.dot(rgb[6, 0] - rgb[0, 0], lwir[-7, 0] - lwir[-1, 0])
    score_flip += np.dot(rgb[28, 0] - rgb[0, 0], lwir[-29, 0] - lwir[-1, 0])
    return lwir if score_same >= score_flip else lwir[::-1].copy()


def calibrate(obj, rgb, lwir):
    criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_MAX_ITER, 200, 1e-10)
    rr, kr, dr, _, _ = cv2.calibrateCamera(obj, rgb, (1280, 720), None, None, criteria=criteria)
    rt, kt, dt, _, _ = cv2.calibrateCamera(obj, lwir, (160, 120), None, None, criteria=criteria)
    out = cv2.stereoCalibrateExtended(
        obj, rgb, lwir, kr, dr, kt, dt, (1280, 720),
        None, None,
        criteria=criteria, flags=cv2.CALIB_FIX_INTRINSIC)
    rs, _, _, _, _, rot, trans, essential, fundamental, _, _, per_view = out
    per_view = np.asarray(per_view)
    if per_view.ndim == 2 and per_view.shape[1] == 2:
        per_view = np.sqrt(np.mean(per_view * per_view, axis=1))
    else:
        per_view = per_view.ravel()
    return rr, rt, rs, kr, dr, kt, dt, rot, trans, essential, fundamental, per_view


def matrix(x):
    return np.asarray(x).tolist()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", type=Path)
    ap.add_argument("--square-mm", type=float, default=33.0)
    ap.add_argument("--max-skew-ms", type=float, default=40.0)
    ap.add_argument("--output", type=Path, default=Path("calibration_rgb_lwir"))
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    rows = list(csv.DictReader((args.data / "pairs.csv").open()))
    template = np.zeros((PATTERN[0] * PATTERN[1], 3), np.float32)
    template[:, :2] = np.mgrid[0:PATTERN[0], 0:PATTERN[1]].T.reshape(-1, 2)
    template *= args.square_mm
    records = []
    for row in rows:
        if float(row["receive_skew_ms"]) > args.max_skew_ms:
            continue
        rp, tp = args.data / row["rgb_file"], args.data / row["lwir_file"]
        rim = cv2.imread(str(rp), cv2.IMREAD_GRAYSCALE)
        tim = cv2.imread(str(tp), cv2.IMREAD_UNCHANGED)
        if rim is None or tim is None:
            continue
        rc = detect([rim])
        tc = detect(thermal_u8(tim))
        if rc is not None and tc is not None:
            records.append({"id": int(row["pair_id"]), "skew": float(row["receive_skew_ms"]),
                            "rgb": rc, "lwir": align_order(rc, tc), "rgb_path": rp, "lwir_path": tp})
    if len(records) < 10:
        raise SystemExit(f"Only {len(records)} usable pairs; at least 10 are required")

    active = list(range(len(records)))
    rejected = []
    # Robustly discard only severe stereo outliers, retaining at least 15 views.
    for _ in range(5):
        obj = [template] * len(active)
        result = calibrate(obj, [records[i]["rgb"] for i in active], [records[i]["lwir"] for i in active])
        errors = result[-1]
        med = float(np.median(errors))
        mad = float(np.median(np.abs(errors - med)))
        limit = max(2.0, med + 3.5 * 1.4826 * mad)
        bad_local = [j for j, e in enumerate(errors) if e > limit]
        if not bad_local or len(active) - len(bad_local) < 15:
            break
        for j in reversed(bad_local):
            rejected.append(active.pop(j))
    obj = [template] * len(active)
    rr, rt, rs, kr, dr, kt, dt, rot, trans, essential, fundamental, errors = calibrate(
        obj, [records[i]["rgb"] for i in active], [records[i]["lwir"] for i in active])

    result = {
        "convention": "X_lwir = R_rgb_to_lwir * X_rgb + T_rgb_to_lwir_mm",
        "checkerboard": {"inner_corners": list(PATTERN), "square_size_mm": args.square_mm},
        "image_size": {"rgb": [1280, 720], "lwir": [160, 120]},
        "selection": {"max_receive_skew_ms": args.max_skew_ms,
                      "detected_pairs": len(records), "used_pairs": len(active),
                      "used_pair_ids": [records[i]["id"] for i in active],
                      "rejected_pair_ids": [records[i]["id"] for i in rejected]},
        "rms_px": {"rgb_intrinsic": rr, "lwir_intrinsic": rt, "stereo": rs,
                   "stereo_per_view_median": float(np.median(errors)),
                   "stereo_per_view_max": float(np.max(errors))},
        "rgb": {"camera_matrix": matrix(kr), "distortion": matrix(dr.ravel())},
        "lwir": {"camera_matrix": matrix(kt), "distortion": matrix(dt.ravel())},
        "extrinsics": {"R_rgb_to_lwir": matrix(rot), "T_rgb_to_lwir_mm": matrix(trans.ravel()),
                       "baseline_mm": float(np.linalg.norm(trans))},
        "essential": matrix(essential), "fundamental": matrix(fundamental),
    }
    (args.output / "calibration.json").write_text(json.dumps(result, indent=2) + "\n")
    np.savez(args.output / "calibration.npz", K_rgb=kr, D_rgb=dr, K_lwir=kt, D_lwir=dt,
             R_rgb_to_lwir=rot, T_rgb_to_lwir_mm=trans, E=essential, F=fundamental)

    # Save corner-detection evidence for six distributed accepted views.
    picks = np.linspace(0, len(active) - 1, min(6, len(active)), dtype=int)
    tiles = []
    for j in picks:
        rec = records[active[j]]
        ri = cv2.imread(str(rec["rgb_path"])); ti = thermal_u8(cv2.imread(str(rec["lwir_path"]), -1))[1]
        ti = cv2.cvtColor(ti, cv2.COLOR_GRAY2BGR)
        cv2.drawChessboardCorners(ri, PATTERN, rec["rgb"], True)
        cv2.drawChessboardCorners(ti, PATTERN, rec["lwir"], True)
        ti = cv2.resize(ti, (960, 720), interpolation=cv2.INTER_NEAREST)
        tiles.append(cv2.resize(np.hstack([ri, ti]), (640, 240)))
    cv2.imwrite(str(args.output / "detections.jpg"), np.vstack(tiles))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
