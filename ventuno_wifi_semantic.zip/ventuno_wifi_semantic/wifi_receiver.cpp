#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <functional>
#include <iostream>
#include <map>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>

namespace {
constexpr std::uint32_t MAX_MESSAGE_BYTES = 65536;
constexpr std::size_t MAX_HTTP_REQUEST_BYTES = 8192;

struct Config {
    int tcp_port = 5000;
    int http_port = 8080;
    std::size_t history_limit = 100;
};

struct Message {
    std::uint64_t id;
    std::string received_at;
    std::string text;
    unsigned long long target_bps = 0;
    double actual_bps = 0;
    double elapsed_ms = 0;
};

struct BandStats {
    std::uint64_t samples = 0;
    double actual_bps_total = 0;
    double peak_bps = 0;
};

struct ImuSample {
    std::uint64_t id = 0;
    std::string received_at;
    double x = 0, y = 0, z = 0;
    double roll = 0, pitch = 0, yaw = 0;
    double ax = 0, ay = 0, az = 0;
    double gx = 0, gy = 0, gz = 0;
};

struct ReceiverState {
    std::mutex mutex;
    bool connected = false;
    std::string peer;
    std::string last_received;
    std::uint64_t message_count = 0;
    std::uint64_t payload_total = 0;
    unsigned long long current_target_bps = 0;
    double last_actual_bps = 0;
    std::map<unsigned long long, BandStats> bands;
    std::deque<Message> messages;
    bool imu_connected = false;
    std::string imu_peer;
    std::string imu_device_id;
    std::string imu_last_received;
    std::uint64_t imu_sample_count = 0;
    ImuSample imu_latest;
    std::deque<ImuSample> imu_trail;
};

unsigned long long parse_unsigned(const std::string& value, const std::string& option) {
    if (value.empty() || value[0] == '-') throw std::runtime_error("Invalid " + option);
    std::size_t pos = 0;
    auto number = std::stoull(value, &pos);
    if (pos != value.size()) throw std::runtime_error("Invalid " + option);
    return number;
}

Config parse_args(int argc, char** argv) {
    Config config;
    for (int i = 1; i < argc; ++i) {
        std::string option = argv[i];
        if (option == "--help" || option == "-h") {
            std::cout << "Usage: " << argv[0]
                      << " [--port 5000] [--http-port 8080] [--history 100]\n";
            std::exit(0);
        }
        if ((option == "--port" || option == "--http-port" || option == "--history") && i + 1 < argc) {
            std::string value = argv[++i];
            auto number = parse_unsigned(value, option);
            if (option == "--history") {
                if (number == 0 || number > 10000) {
                    throw std::runtime_error("--history must be in 1..10000");
                }
                config.history_limit = static_cast<std::size_t>(number);
            } else {
                if (number == 0 || number > 65535) {
                    throw std::runtime_error(option + " must be in 1..65535");
                }
                if (option == "--port") config.tcp_port = static_cast<int>(number);
                else config.http_port = static_cast<int>(number);
            }
        } else {
            throw std::runtime_error("Unknown/missing option: " + option);
        }
    }
    if (config.tcp_port == config.http_port) {
        throw std::runtime_error("TCP port and HTTP port must be different");
    }
    return config;
}

bool recv_exact(int socket_fd, void* buffer, std::size_t length) {
    auto* bytes = static_cast<std::uint8_t*>(buffer);
    std::size_t received = 0;
    while (received < length) {
        ssize_t count = recv(socket_fd, bytes + received, length - received, 0);
        if (count < 0 && errno == EINTR) continue;
        if (count < 0) throw std::runtime_error(std::string("recv: ") + std::strerror(errno));
        if (count == 0) {
            if (received != 0) std::cerr << "[WARN] Peer closed during a frame.\n";
            return false;
        }
        received += static_cast<std::size_t>(count);
    }
    return true;
}

void send_all(int socket_fd, const char* data, std::size_t length) {
    std::size_t sent = 0;
    while (sent < length) {
        ssize_t count = send(socket_fd, data + sent, length - sent, MSG_NOSIGNAL);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) return;
        sent += static_cast<std::size_t>(count);
    }
}

int make_listener(int port, int backlog) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) throw std::runtime_error("socket failed");
    int yes = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    sockaddr_in address {};
    address.sin_family = AF_INET;
    address.sin_port = htons(static_cast<std::uint16_t>(port));
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(fd, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0) {
        auto error = std::strerror(errno);
        close(fd);
        throw std::runtime_error(std::string("bind: ") + error);
    }
    if (listen(fd, backlog) != 0) {
        auto error = std::strerror(errno);
        close(fd);
        throw std::runtime_error(std::string("listen: ") + error);
    }
    return fd;
}

std::string current_local_time() {
    auto now = std::chrono::system_clock::now();
    std::time_t value = std::chrono::system_clock::to_time_t(now);
    std::tm local {};
    localtime_r(&value, &local);
    char buffer[32] = {};
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", &local);
    return buffer;
}

std::string json_escape(const std::string& value) {
    std::ostringstream output;
    for (unsigned char character : value) {
        switch (character) {
            case '"': output << "\\\""; break;
            case '\\': output << "\\\\"; break;
            case '\b': output << "\\b"; break;
            case '\f': output << "\\f"; break;
            case '\n': output << "\\n"; break;
            case '\r': output << "\\r"; break;
            case '\t': output << "\\t"; break;
            default:
                if (character < 0x20) {
                    const char* digits = "0123456789abcdef";
                    output << "\\u00" << digits[character >> 4] << digits[character & 0x0f];
                } else {
                    output << static_cast<char>(character);
                }
        }
    }
    return output.str();
}

std::string state_as_json(ReceiverState& state) {
    std::lock_guard<std::mutex> lock(state.mutex);
    std::ostringstream json;
    json << "{\"connected\":" << (state.connected ? "true" : "false")
         << ",\"peer\":\"" << json_escape(state.peer) << "\""
         << ",\"last_received\":\"" << json_escape(state.last_received) << "\""
         << ",\"message_count\":" << state.message_count
         << ",\"payload_total\":" << state.payload_total
         << ",\"current_target_bps\":" << state.current_target_bps
         << ",\"last_actual_bps\":" << state.last_actual_bps
         << ",\"messages\":[";
    bool first = true;
    for (auto iterator = state.messages.rbegin(); iterator != state.messages.rend(); ++iterator) {
        if (!first) json << ',';
        first = false;
        json << "{\"id\":" << iterator->id
             << ",\"received_at\":\"" << json_escape(iterator->received_at) << "\""
             << ",\"text\":\"" << json_escape(iterator->text) << "\""
             << ",\"target_bps\":" << iterator->target_bps
             << ",\"actual_bps\":" << iterator->actual_bps
             << ",\"elapsed_ms\":" << iterator->elapsed_ms << "}";
    }
    json << "],\"bands\":[";
    first = true;
    for (const auto& entry : state.bands) {
        if (!first) json << ',';
        first = false;
        const auto& stats = entry.second;
        json << "{\"target_bps\":" << entry.first
             << ",\"samples\":" << stats.samples
             << ",\"average_bps\":"
             << (stats.samples ? stats.actual_bps_total / static_cast<double>(stats.samples) : 0)
             << ",\"peak_bps\":" << stats.peak_bps << "}";
    }
    json << "],\"imu\":{\"connected\":" << (state.imu_connected ? "true" : "false")
         << ",\"origin_lat\":37.55081,\"origin_lon\":127.07423"
         << ",\"peer\":\"" << json_escape(state.imu_peer) << "\""
         << ",\"device_id\":\"" << json_escape(state.imu_device_id) << "\""
         << ",\"last_received\":\"" << json_escape(state.imu_last_received) << "\""
         << ",\"sample_count\":" << state.imu_sample_count
         << ",\"latest\":{"
         << "\"x\":" << state.imu_latest.x << ",\"y\":" << state.imu_latest.y << ",\"z\":" << state.imu_latest.z
         << ",\"roll\":" << state.imu_latest.roll << ",\"pitch\":" << state.imu_latest.pitch << ",\"yaw\":" << state.imu_latest.yaw
         << ",\"ax\":" << state.imu_latest.ax << ",\"ay\":" << state.imu_latest.ay << ",\"az\":" << state.imu_latest.az
         << ",\"gx\":" << state.imu_latest.gx << ",\"gy\":" << state.imu_latest.gy << ",\"gz\":" << state.imu_latest.gz << "}"
         << ",\"trail\":[";
    first = true;
    for (const auto& sample : state.imu_trail) {
        if (!first) json << ',';
        first = false;
        json << "{\"id\":" << sample.id << ",\"x\":" << sample.x << ",\"y\":" << sample.y
             << ",\"yaw\":" << sample.yaw << ",\"received_at\":\""
             << json_escape(sample.received_at) << "\"}";
    }
    json << "]}}";
    return json.str();
}

const char* DASHBOARD_HTML = R"HTML(<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ventuno Q VLM Monitor</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
  <style>
    :root { color-scheme:dark; --panel:#141b2d; --line:#25304a; --muted:#91a0bd; --text:#eef3ff; --accent:#63e6be; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:Inter,system-ui,sans-serif; background:linear-gradient(135deg,#080c18,#111a30); color:var(--text); min-height:100vh; }
    main { width:min(1100px,calc(100% - 32px)); margin:0 auto; padding:32px 0 48px; }
    header { display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:22px; }
    h1 { margin:0; font-size:clamp(24px,4vw,38px); letter-spacing:-.04em; }
    .subtitle { color:var(--muted); margin-top:7px; }
    .status { display:flex; align-items:center; gap:9px; padding:10px 14px; border:1px solid var(--line); border-radius:999px; background:#101729; white-space:nowrap; }
    .device-statuses { display:flex; gap:8px; flex-wrap:wrap; }
    .dot { width:10px; height:10px; border-radius:50%; background:#68738a; box-shadow:0 0 0 4px #68738a22; }
    .online .dot { background:var(--accent); box-shadow:0 0 0 4px #63e6be22; }
    .grid { display:grid; grid-template-columns:repeat(3,1fr); gap:14px; }
    .panel { background:#141b2ddd; border:1px solid var(--line); border-radius:18px; padding:20px; box-shadow:0 16px 40px #0003; }
    .metric-label { color:var(--muted); font-size:13px; }
    .metric-value { margin-top:8px; font-size:20px; font-weight:700; overflow-wrap:anywhere; }
    .latest { margin-top:14px; min-height:180px; }
    .section-title { margin:0 0 14px; font-size:15px; color:var(--muted); font-weight:600; }
    #latestText { font-size:clamp(20px,3vw,30px); line-height:1.45; white-space:pre-wrap; overflow-wrap:anywhere; }
    .alert { display:none; margin-top:14px; padding:13px 15px; border-radius:12px; color:#ffe3e3; background:#5d2028; border:1px solid #a83b49; }
    .speed-panel { margin-top:14px; }
    .imu-panel { margin-top:14px; }
    .imu-layout { display:grid; grid-template-columns:minmax(0,1.5fr) minmax(280px,1fr); gap:16px; }
    #imuMap { height:360px; border:1px solid var(--line); border-radius:12px; overflow:hidden; background:#0b1120; }
    .leaflet-container { font-family:Inter,system-ui,sans-serif; }
    .imu-values { display:grid; grid-template-columns:1fr 1fr; gap:10px; align-content:start; }
    .imu-value { padding:13px; background:#0d1425; border:1px solid var(--line); border-radius:12px; }
    .imu-value strong { display:block; margin-top:6px; font-size:18px; }
    .wide { grid-column:1/-1; }
    .speed-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:10px; margin-bottom:18px; }
    .speed-metric { padding:14px; border:1px solid var(--line); border-radius:12px; background:#0d1425; }
    .speed-metric strong { display:block; margin-top:7px; font-size:19px; }
    canvas { display:block; width:100%; height:220px; background:#0b1120; border:1px solid var(--line); border-radius:12px; }
    .table-wrap { margin-top:16px; overflow:auto; }
    table { width:100%; border-collapse:collapse; font-variant-numeric:tabular-nums; }
    th,td { padding:11px 12px; border-bottom:1px solid var(--line); text-align:right; white-space:nowrap; }
    th:first-child,td:first-child { text-align:left; }
    th { color:var(--muted); font-size:12px; font-weight:600; }
    .controls { display:flex; margin:14px 0; }
    input { flex:1; min-width:0; background:#0d1425; color:var(--text); border:1px solid var(--line); border-radius:10px; padding:11px 13px; outline:none; }
    input:focus { border-color:#4b77be; }
    .history { padding:0; overflow:hidden; }
    .history-head { display:flex; align-items:center; justify-content:space-between; padding:18px 20px; border-bottom:1px solid var(--line); }
    .history-head h2 { margin:0; font-size:17px; }
    #history { max-height:460px; overflow:auto; }
    .row { display:grid; grid-template-columns:86px 1fr; gap:14px; padding:15px 20px; border-bottom:1px solid var(--line); }
    .row:last-child { border-bottom:0; }
    .row time { color:var(--muted); font-variant-numeric:tabular-nums; }
    .row p { margin:0; line-height:1.45; white-space:pre-wrap; overflow-wrap:anywhere; }
    .row.warning { background:#52202955; }
    .empty { color:var(--muted); text-align:center; padding:42px 20px; }
    .foot { margin-top:12px; text-align:right; color:var(--muted); font-size:12px; }
    @media (max-width:800px) { header { align-items:flex-start; flex-direction:column; } .imu-layout { grid-template-columns:1fr; } }
    @media (max-width:700px) { .grid,.speed-grid { grid-template-columns:1fr 1fr; } .row { grid-template-columns:1fr; gap:5px; } }
  </style>
</head>
<body>
<main>
  <header>
    <div><h1>Ventuno Q VLM Monitor</h1><div class="subtitle">VLM 추론 결과 실시간 수신 대시보드</div></div>
    <div class="device-statuses">
      <div id="status" class="status"><span class="dot"></span><span id="statusText">VLM 확인 중</span></div>
      <div id="imuStatus" class="status"><span class="dot"></span><span id="imuStatusText">IMU 확인 중</span></div>
    </div>
  </header>
  <section class="grid">
    <article class="panel"><div class="metric-label">Ventuno Q</div><div id="peer" class="metric-value">-</div></article>
    <article class="panel"><div class="metric-label">마지막 수신 시간</div><div id="lastReceived" class="metric-value">-</div></article>
    <article class="panel"><div class="metric-label">수신 메시지</div><div id="messageCount" class="metric-value">0건</div></article>
  </section>
  <section class="panel imu-panel">
    <h2 class="section-title">IMU 위치 및 자세</h2>
    <div class="imu-layout">
      <div id="imuMap" aria-label="IMU 현재 위치 지도"></div>
      <div class="imu-values">
        <div class="imu-value wide"><span class="metric-label">위치 X / Y</span><strong id="imuPosition">0.00 / 0.00 m</strong></div>
        <div class="imu-value"><span class="metric-label">Roll</span><strong id="imuRoll">-</strong></div>
        <div class="imu-value"><span class="metric-label">Pitch</span><strong id="imuPitch">-</strong></div>
        <div class="imu-value"><span class="metric-label">Yaw</span><strong id="imuYaw">-</strong></div>
        <div class="imu-value wide"><span class="metric-label">마지막 수신 / 샘플</span><strong id="imuMeta">-</strong></div>
      </div>
    </div>
  </section>
  <section class="panel latest">
    <h2 class="section-title">최신 VLM 출력</h2>
    <div id="latestText">아직 수신된 메시지가 없습니다.</div>
    <div id="alert" class="alert"></div>
  </section>
  <section class="panel speed-panel">
    <h2 class="section-title">전송 속도 측정</h2>
    <div class="speed-grid">
      <div class="speed-metric"><span class="metric-label">설정 속도</span><strong id="targetRate">-</strong></div>
      <div class="speed-metric"><span class="metric-label">최근 실측</span><strong id="actualRate">-</strong></div>
      <div class="speed-metric"><span class="metric-label">현재 대역 평균</span><strong id="averageRate">-</strong></div>
      <div class="speed-metric"><span class="metric-label">현재 대역 최고</span><strong id="peakRate">-</strong></div>
    </div>
    <canvas id="speedChart" aria-label="메시지별 전송 속도 그래프"></canvas>
    <div class="table-wrap">
      <table><thead><tr><th>설정 속도</th><th>실측 평균</th><th>최고 속도</th><th>메시지</th></tr></thead><tbody id="bandRows"></tbody></table>
    </div>
  </section>
  <div class="controls"><input id="keywords" aria-label="경고 키워드" placeholder="경고 키워드 (쉼표 구분): fire, smoke, danger"></div>
  <section class="panel history">
    <div class="history-head"><h2>이전 VLM 출력</h2><span id="historyCount" class="metric-label">0개 표시</span></div>
    <div id="history"><div class="empty">수신 대기 중입니다.</div></div>
  </section>
  <div id="updated" class="foot"></div>
</main>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
  const $ = id => document.getElementById(id);
  const keywordInput = $('keywords');
  keywordInput.value = localStorage.getItem('ventuno-warning-keywords') || '';
  keywordInput.addEventListener('input', () => {
    localStorage.setItem('ventuno-warning-keywords', keywordInput.value);
    if (window.lastState) render(window.lastState);
  });
  function keywords() { return keywordInput.value.split(',').map(v => v.trim().toLowerCase()).filter(Boolean); }
  function matched(text) { const lower = text.toLowerCase(); return keywords().filter(word => lower.includes(word)); }
  function timeOnly(value) { return value ? value.slice(11) : '-'; }
  function formatBps(value) {
    if (!Number.isFinite(value) || value <= 0) return '-';
    return `${Math.round(value).toLocaleString()} bps`;
  }
  function targetLabel(value) { return value === 0 ? '제한 없음' : `${value.toLocaleString()} bps`; }
  function drawSpeedChart(messages) {
    const canvas = $('speedChart');
    const ratio = window.devicePixelRatio || 1;
    const width = Math.max(300, canvas.clientWidth);
    const height = 220;
    canvas.width = width * ratio; canvas.height = height * ratio;
    const ctx = canvas.getContext('2d'); ctx.scale(ratio, ratio);
    ctx.clearRect(0, 0, width, height);
    const points = messages.filter(m => m.actual_bps > 0).slice(0, 40).reverse();
    if (!points.length) {
      ctx.fillStyle = '#91a0bd'; ctx.font = '14px system-ui'; ctx.textAlign = 'center';
      ctx.fillText('속도 측정값을 기다리는 중입니다.', width / 2, height / 2); return;
    }
    const pad = {left:58,right:16,top:18,bottom:30};
    const maxValue = Math.max(...points.map(p => Math.max(p.actual_bps, p.target_bps || 0)), 1) * 1.12;
    const x = i => pad.left + i * (width-pad.left-pad.right) / Math.max(points.length-1, 1);
    const y = v => pad.top + (height-pad.top-pad.bottom) * (1-v/maxValue);
    ctx.strokeStyle='#25304a'; ctx.fillStyle='#91a0bd'; ctx.font='11px system-ui'; ctx.textAlign='right';
    for (let i=0;i<=4;i++) { const value=maxValue*i/4; const py=y(value); ctx.beginPath(); ctx.moveTo(pad.left,py); ctx.lineTo(width-pad.right,py); ctx.stroke(); ctx.fillText(Math.round(value).toLocaleString(),pad.left-7,py+4); }
    ctx.strokeStyle='#63e6be'; ctx.lineWidth=2.5; ctx.beginPath();
    points.forEach((p,i)=>{ const px=x(i),py=y(p.actual_bps); i?ctx.lineTo(px,py):ctx.moveTo(px,py); }); ctx.stroke();
    ctx.fillStyle='#63e6be'; points.forEach((p,i)=>{ ctx.beginPath(); ctx.arc(x(i),y(p.actual_bps),3,0,Math.PI*2); ctx.fill(); });
    ctx.fillStyle='#91a0bd'; ctx.textAlign='center'; ctx.fillText('최근 메시지 →', (pad.left+width-pad.right)/2, height-8);
  }
  function renderBands(bands) {
    const body = $('bandRows'); body.replaceChildren();
    const byTarget = new Map(bands.map(band => [band.target_bps, band]));
    const targets = [...new Set([500, 1000, 2000, 5000, 10000, ...byTarget.keys()])].sort((a,b) => a-b);
    for (const target of targets) {
      const band = byTarget.get(target) || {target_bps:target, samples:0, average_bps:0, peak_bps:0};
      const row=body.insertRow();
      [targetLabel(band.target_bps), formatBps(band.average_bps), formatBps(band.peak_bps), band.samples ? `${band.samples}건` : '-']
        .forEach(value=>{ const cell=row.insertCell(); cell.textContent=value; });
    }
  }
  function fixed(value, digits=2) { return Number.isFinite(value) ? value.toFixed(digits) : '-'; }
  let imuMap, imuMarker;
  function localToMap(imu) {
    const latitude=Number.isFinite(imu.origin_lat)?imu.origin_lat:37.55081;
    const longitude=Number.isFinite(imu.origin_lon)?imu.origin_lon:127.07423;
    const sample=imu.sample_count ? (imu.latest||{}) : {x:0,y:0};
    const x=Number.isFinite(sample.x)?sample.x:0, y=Number.isFinite(sample.y)?sample.y:0;
    return [latitude+y/111320, longitude+x/(111320*Math.cos(latitude*Math.PI/180))];
  }
  function updateImuMap(imu) {
    const position=localToMap(imu);
    if (!window.L) {
      $('imuMap').textContent='지도를 불러오지 못했습니다. 인터넷 연결을 확인하세요.';
      return;
    }
    if (!imuMap) {
      imuMap=L.map('imuMap').setView(position,17);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{
        maxZoom:19,
        attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }).addTo(imuMap);
      imuMarker=L.circleMarker(position,{radius:9,color:'#fff',weight:3,fillColor:'#ef4444',fillOpacity:1})
        .addTo(imuMap).bindPopup('IMU 현재 위치<br>세종대학교').openPopup();
    } else {
      imuMarker.setLatLng(position);
    }
  }
  function renderImu(imu) {
    $('imuStatus').classList.toggle('online',imu.connected);
    $('imuStatusText').textContent=imu.connected?'IMU Connected':'IMU Disconnected';
    const v=imu.latest||{};
    $('imuPosition').textContent=imu.sample_count?`${fixed(v.x)} / ${fixed(v.y)} m`:'0.00 / 0.00 m';
    $('imuRoll').textContent=imu.sample_count?`${fixed(v.roll,1)}°`:'-';
    $('imuPitch').textContent=imu.sample_count?`${fixed(v.pitch,1)}°`:'-';
    $('imuYaw').textContent=imu.sample_count?`${fixed(v.yaw,1)}°`:'-';
    $('imuMeta').textContent=imu.sample_count?`${imu.last_received} · ${imu.sample_count.toLocaleString()}개`:'-';
    updateImuMap(imu);
  }
  function render(data) {
    window.lastState = data;
    $('status').classList.toggle('online', data.connected);
    $('statusText').textContent = data.connected ? 'Connected' : 'Disconnected';
    $('peer').textContent = data.peer || '-';
    $('lastReceived').textContent = data.last_received || '-';
    $('messageCount').textContent = `${data.message_count.toLocaleString()}건`;
    const band = data.bands.find(item => item.target_bps === data.current_target_bps);
    $('targetRate').textContent = data.connected ? targetLabel(data.current_target_bps) : '-';
    $('actualRate').textContent = formatBps(data.last_actual_bps);
    $('averageRate').textContent = band ? formatBps(band.average_bps) : '-';
    $('peakRate').textContent = band ? formatBps(band.peak_bps) : '-';
    renderBands(data.bands);
    drawSpeedChart(data.messages);
    renderImu(data.imu || {connected:false,sample_count:0,trail:[],latest:{}});
    const latest = data.messages[0];
    $('latestText').textContent = latest ? latest.text : '아직 수신된 메시지가 없습니다.';
    const hits = latest ? matched(latest.text) : [];
    $('alert').style.display = hits.length ? 'block' : 'none';
    $('alert').textContent = hits.length ? `경고 키워드 감지: ${hits.join(', ')}` : '';
    const history = $('history');
    history.replaceChildren();
    if (!data.messages.length) {
      const empty = document.createElement('div'); empty.className = 'empty'; empty.textContent = '수신 대기 중입니다.'; history.append(empty);
    } else {
      for (const message of data.messages) {
        const row = document.createElement('div'); row.className = `row${matched(message.text).length ? ' warning' : ''}`;
        const time = document.createElement('time'); time.textContent = timeOnly(message.received_at);
        const text = document.createElement('p'); text.textContent = message.text;
        row.append(time, text); history.append(row);
      }
    }
    $('historyCount').textContent = `${data.messages.length}개 표시`;
    $('updated').textContent = `화면 갱신: ${new Date().toLocaleTimeString()}`;
  }
  async function refresh() {
    try {
      const response = await fetch('/api/status', { cache:'no-store' });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      render(await response.json());
    } catch (error) {
      $('status').classList.remove('online'); $('statusText').textContent = 'Server error';
      $('updated').textContent = `서버 상태를 읽지 못했습니다: ${error.message}`;
    }
  }
  refresh(); setInterval(refresh, 700);
</script>
</body>
</html>)HTML";

void send_http_response(int client, const std::string& status, const std::string& content_type,
                        const std::string& body) {
    std::ostringstream headers;
    headers << "HTTP/1.1 " << status << "\r\n"
            << "Content-Type: " << content_type << "\r\n"
            << "Content-Length: " << body.size() << "\r\n"
            << "Cache-Control: no-store\r\n"
            << "X-Content-Type-Options: nosniff\r\n"
            << "Connection: close\r\n\r\n";
    auto header_text = headers.str();
    send_all(client, header_text.data(), header_text.size());
    send_all(client, body.data(), body.size());
}

void handle_http_client(int client, ReceiverState& state) {
    std::string request;
    char buffer[2048];
    while (request.find("\r\n\r\n") == std::string::npos && request.size() < MAX_HTTP_REQUEST_BYTES) {
        ssize_t count = recv(client, buffer, sizeof(buffer), 0);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) return;
        request.append(buffer, static_cast<std::size_t>(count));
    }
    auto line_end = request.find("\r\n");
    std::istringstream parser(request.substr(0, line_end));
    std::string method, path, version;
    parser >> method >> path >> version;
    if (method != "GET") {
        send_http_response(client, "405 Method Not Allowed", "text/plain; charset=utf-8", "Method not allowed\n");
    } else if (path == "/" || path == "/index.html") {
        send_http_response(client, "200 OK", "text/html; charset=utf-8", DASHBOARD_HTML);
    } else if (path == "/api/status") {
        send_http_response(client, "200 OK", "application/json; charset=utf-8", state_as_json(state));
    } else if (path == "/favicon.ico") {
        send_http_response(client, "204 No Content", "image/x-icon", "");
    } else {
        send_http_response(client, "404 Not Found", "text/plain; charset=utf-8", "Not found\n");
    }
}

void run_http_server(int port, ReceiverState& state) {
    int listener = make_listener(port, 16);
    std::cout << "[INFO] Dashboard: http://0.0.0.0:" << port << "\n" << std::flush;
    for (;;) {
        int client = accept(listener, nullptr, nullptr);
        if (client < 0 && errno == EINTR) continue;
        if (client < 0) throw std::runtime_error("HTTP accept failed");
        handle_http_client(client, state);
        close(client);
    }
}

enum class ClientKind { Unknown, Vlm, Imu };

void set_vlm_connected(ReceiverState& state, bool connected, const std::string& peer = "") {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.connected = connected;
    state.peer = connected ? peer : "";
    if (connected) {
        state.current_target_bps = 0;
        state.last_actual_bps = 0;
    }
}

void set_imu_connected(ReceiverState& state, bool connected, const std::string& peer = "",
                       const std::string& device_id = "") {
    std::lock_guard<std::mutex> lock(state.mutex);
    state.imu_connected = connected;
    state.imu_peer = connected ? peer : "";
    if (connected) state.imu_device_id = device_id;
}

bool handle_control_message(ReceiverState& state, const std::string& text,
                            const std::string& peer, ClientKind& kind) {
    constexpr const char* CONFIG_PREFIX = "@VENTUNO/1 CONFIG ";
    constexpr const char* STATS_PREFIX = "@VENTUNO/1 STATS ";
    constexpr const char* IMU_CONFIG_PREFIX = "@IMU/1 CONFIG ";
    constexpr const char* IMU_DATA_PREFIX = "@IMU/1 DATA ";
    if (text.rfind(CONFIG_PREFIX, 0) == 0) {
        std::istringstream input(text.substr(std::strlen(CONFIG_PREFIX)));
        unsigned long long target_bps = 0;
        std::string extra;
        if (!(input >> target_bps) || (input >> extra)) return true;
        kind = ClientKind::Vlm;
        std::lock_guard<std::mutex> lock(state.mutex);
        state.connected = true;
        state.peer = peer;
        state.current_target_bps = target_bps;
        std::cout << "[INFO] Sender target rate: "
                  << (target_bps == 0 ? std::string("unlimited") : std::to_string(target_bps) + " bps")
                  << "\n" << std::flush;
        return true;
    }
    if (text.rfind(STATS_PREFIX, 0) == 0) {
        std::istringstream input(text.substr(std::strlen(STATS_PREFIX)));
        unsigned long long target_bps = 0, payload_bytes = 0, framed_bytes = 0, elapsed_ns = 0;
        std::string extra;
        if (!(input >> target_bps >> payload_bytes >> framed_bytes >> elapsed_ns) || (input >> extra)) return true;
        if (framed_bytes != payload_bytes + 4 || payload_bytes > MAX_MESSAGE_BYTES || elapsed_ns == 0) return true;
        double actual_bps = static_cast<double>(framed_bytes) * 8.0 * 1'000'000'000.0
                            / static_cast<double>(elapsed_ns);
        kind = ClientKind::Vlm;
        std::lock_guard<std::mutex> lock(state.mutex);
        state.current_target_bps = target_bps;
        state.last_actual_bps = actual_bps;
        auto& stats = state.bands[target_bps];
        ++stats.samples;
        stats.actual_bps_total += actual_bps;
        if (actual_bps > stats.peak_bps) stats.peak_bps = actual_bps;
        if (!state.messages.empty() && state.messages.back().text.size() == payload_bytes) {
            auto& message = state.messages.back();
            message.target_bps = target_bps;
            message.actual_bps = actual_bps;
            message.elapsed_ms = static_cast<double>(elapsed_ns) / 1'000'000.0;
        }
        return true;
    }
    if (text.rfind(IMU_CONFIG_PREFIX, 0) == 0) {
        std::string device_id = text.substr(std::strlen(IMU_CONFIG_PREFIX));
        if (device_id.empty() || device_id.size() > 64) return true;
        kind = ClientKind::Imu;
        set_imu_connected(state, true, peer, device_id);
        std::cout << "[OK] IMU device " << device_id << " connected from " << peer << "\n" << std::flush;
        return true;
    }
    if (text.rfind(IMU_DATA_PREFIX, 0) == 0) {
        ImuSample sample;
        std::istringstream input(text.substr(std::strlen(IMU_DATA_PREFIX)));
        std::string extra;
        if (!(input >> sample.x >> sample.y >> sample.z
                    >> sample.roll >> sample.pitch >> sample.yaw
                    >> sample.ax >> sample.ay >> sample.az
                    >> sample.gx >> sample.gy >> sample.gz) || (input >> extra)) return true;
        kind = ClientKind::Imu;
        std::lock_guard<std::mutex> lock(state.mutex);
        state.imu_connected = true;
        state.imu_peer = peer;
        sample.id = ++state.imu_sample_count;
        sample.received_at = current_local_time();
        state.imu_last_received = sample.received_at;
        state.imu_latest = sample;
        state.imu_trail.push_back(sample);
        while (state.imu_trail.size() > 300) state.imu_trail.pop_front();
        return true;
    }
    return false;
}

void save_message(ReceiverState& state, const std::string& text, std::size_t history_limit) {
    std::lock_guard<std::mutex> lock(state.mutex);
    ++state.message_count;
    state.payload_total += text.size();
    state.last_received = current_local_time();
    state.messages.push_back({state.message_count, state.last_received, text});
    while (state.messages.size() > history_limit) state.messages.pop_front();
}

void handle_data_client(int client, const std::string& peer, ReceiverState& state,
                        std::size_t history_limit) {
    ClientKind kind = ClientKind::Unknown;
    try {
        for (;;) {
            std::uint32_t network_size = 0;
            if (!recv_exact(client, &network_size, sizeof(network_size))) break;
            std::uint32_t size = ntohl(network_size);
            if (size > MAX_MESSAGE_BYTES) throw std::runtime_error("Rejected oversized frame");
            std::string text(size, '\0');
            if (!recv_exact(client, text.data(), size)) break;
            if (handle_control_message(state, text, peer, kind)) continue;
            if (kind == ClientKind::Unknown) {
                kind = ClientKind::Vlm;
                set_vlm_connected(state, true, peer);
                std::cout << "[OK] Legacy VLM sender identified from " << peer << "\n" << std::flush;
            }
            if (kind == ClientKind::Vlm) {
                save_message(state, text, history_limit);
                std::cout << "[VLM] " << size << " bytes: " << text << "\n" << std::flush;
            }
        }
    } catch (const std::exception& error) {
        std::cerr << "[WARN] Client " << peer << ": " << error.what() << "\n";
    }
    close(client);
    if (kind == ClientKind::Vlm) {
        set_vlm_connected(state, false);
        std::cout << "[INFO] VLM sender disconnected: " << peer << "\n" << std::flush;
    } else if (kind == ClientKind::Imu) {
        set_imu_connected(state, false);
        std::cout << "[INFO] IMU sender disconnected: " << peer << "\n" << std::flush;
    }
}
} // namespace

int main(int argc, char** argv) {
    try {
        Config config = parse_args(argc, argv);
        ReceiverState state;
        std::thread http_thread([&] {
            try {
                run_http_server(config.http_port, state);
            } catch (const std::exception& error) {
                std::cerr << "[ERROR] HTTP server: " << error.what() << "\n";
                std::exit(1);
            }
        });
        http_thread.detach();

        int listener = make_listener(config.tcp_port, 16);
        std::cout << "Ubuntu PC Wi-Fi Semantic Receiver\n"
                  << "[INFO] VLM + IMU TCP receiver: 0.0.0.0:" << config.tcp_port << "\n"
                  << "[INFO] Open http://<PC_IP>:" << config.http_port << " in a browser.\n"
                  << "[INFO] Ctrl+C to stop.\n" << std::flush;
        for (;;) {
            sockaddr_in peer_address {};
            socklen_t peer_length = sizeof(peer_address);
            int client = accept(listener, reinterpret_cast<sockaddr*>(&peer_address), &peer_length);
            if (client < 0 && errno == EINTR) continue;
            if (client < 0) throw std::runtime_error("TCP accept failed");
            char ip[INET_ADDRSTRLEN] = {};
            inet_ntop(AF_INET, &peer_address.sin_addr, ip, sizeof(ip));
            std::string peer = std::string(ip) + ":" + std::to_string(ntohs(peer_address.sin_port));
            std::cout << "[INFO] New data connection from " << peer << "\n" << std::flush;
            std::thread(handle_data_client, client, peer, std::ref(state), config.history_limit).detach();
        }
    } catch (const std::exception& error) {
        std::cerr << "[ERROR] " << error.what() << "\n";
        return 1;
    }
}
