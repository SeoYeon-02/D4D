#!/usr/bin/env python3
"""Forward all_pipeline result JSON files to the Ventuno TCP dashboard."""

from __future__ import annotations

import argparse
import json
import socket
import struct
import time
from pathlib import Path
from typing import Any, Iterable


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Watch all_pipeline JSON output and send readable results to the GUI."
    )
    parser.add_argument("--host", required=True, help="GUI receiver PC IPv4 address")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--path", type=Path, required=True,
                        help="A result JSON file or runtime_output directory")
    parser.add_argument("--poll-ms", type=int, default=500)
    parser.add_argument("--once", action="store_true",
                        help="Send current result files once and exit")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be in 1..65535")
    if args.poll_ms < 50:
        parser.error("--poll-ms must be at least 50")
    return args


def result_files(path: Path) -> Iterable[Path]:
    if path.is_file():
        yield path
        return
    if path.is_dir():
        for candidate in sorted(path.glob("*.json")):
            if candidate.name != "tracker_state.json":
                yield candidate


def number(value: Any, digits: int = 3) -> str:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return "-"
    return f"{value:.{digits}f}"


def prediction_lines(prediction: Any) -> list[str]:
    if not isinstance(prediction, dict):
        return ["VLM 판독: 결과 없음"]
    limits = prediction.get("observation_limits")
    limit_text = ", ".join(map(str, limits)) if isinstance(limits, list) and limits else "없음"
    return [
        f"노출={prediction.get('exposure', '-')} · 가림={prediction.get('occluder', '-')}",
        f"형상={prediction.get('visible_shape', '-')} · 색상={prediction.get('visible_color', '-')}",
        f"지면={prediction.get('terrain', '-')} · 관찰 제한={limit_text}",
    ]


def source_bytes(data: dict[str, Any]) -> int | None:
    total = 0
    found = False
    for key in ("rgb", "lwir"):
        value = data.get(key)
        if not isinstance(value, str) or not value:
            continue
        try:
            path = Path(value)
            if path.is_file():
                total += path.stat().st_size
                found = True
        except OSError:
            pass
    return total if found else None


def meaningful(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return value.strip().lower() not in {"", "-", "unknown", "null"}
    return True


def retained_fields(data: dict[str, Any], detections: list[Any], vlm_rows: list[Any]) -> tuple[int, int]:
    # Detection state is always one required semantic field. Each detected object
    # adds class, confidence, exposure, occluder, shape, color, terrain and limits.
    kept = 1 if isinstance(data.get("mine_detected"), bool) else 0
    total = 1 + 8 * len(detections)
    for row in vlm_rows[:len(detections)]:
        if not isinstance(row, dict):
            continue
        detection = row.get("detection") if isinstance(row.get("detection"), dict) else {}
        prediction = row.get("prediction") if isinstance(row.get("prediction"), dict) else {}
        kept += int(meaningful(detection.get("class_name")))
        kept += int(meaningful(detection.get("confidence")))
        for key in ("exposure", "occluder", "visible_shape", "visible_color", "terrain"):
            kept += int(meaningful(prediction.get(key)))
        kept += int(isinstance(prediction.get("observation_limits"), list))
    return kept, total


def format_result(data: dict[str, Any], source: Path) -> str:
    yolo = data.get("yolo") if isinstance(data.get("yolo"), dict) else {}
    detections = yolo.get("detections") if isinstance(yolo.get("detections"), list) else []
    vlm_rows = data.get("vlm_results") if isinstance(data.get("vlm_results"), list) else []
    mine_detected = bool(data.get("mine_detected"))
    lines = [
        f"[PIPELINE {'위험물 탐지' if mine_detected else '탐지 없음'}] {source.name}",
        f"YOLO 감지 {len(detections)}건 · VLM 결과 {len(vlm_rows)}건",
    ]
    for index, row in enumerate(vlm_rows, 1):
        if not isinstance(row, dict):
            continue
        detection = row.get("detection") if isinstance(row.get("detection"), dict) else {}
        class_name = detection.get("class_name", "unknown")
        confidence = detection.get("confidence")
        confidence_text = f"{confidence * 100:.1f}%" if isinstance(confidence, (int, float)) else "-"
        track = row.get("track_id")
        track_text = f" · Track {track}" if track is not None else ""
        lines.append(f"#{index} {class_name} {confidence_text}{track_text}")
        lines.extend(prediction_lines(row.get("prediction")))
        warning = row.get("schema_validation_error")
        if warning:
            lines.append(f"스키마 경고={warning}")
    vlm_latency = sum(
        float(row.get("latency_s", 0)) for row in vlm_rows
        if isinstance(row, dict) and isinstance(row.get("latency_s"), (int, float))
    )
    lines.append(
        "지연시간: "
        f"YOLO {number(yolo.get('latency_s'))}s · "
        f"VLM {number(vlm_latency)}s · 전체 {number(data.get('total_latency_s'))}s"
    )
    base_message = "\n".join(lines)
    original = source_bytes(data)
    kept, total = retained_fields(data, detections, vlm_rows)
    original_text = str(original) if original is not None else "-"
    semantic_bytes = len(base_message.encode("utf-8"))
    while True:
        metric = (f"통신 지표: 원본 {original_text} bytes · 의미 {semantic_bytes} bytes "
                  f"· 정보 {kept}/{total}")
        message = f"{base_message}\n{metric}"
        measured = len(message.encode("utf-8"))
        if measured == semantic_bytes:
            return message
        semantic_bytes = measured


def send_frame(connection: socket.socket, text: str) -> int:
    payload = text.encode("utf-8")
    if len(payload) > 65536:
        raise ValueError(f"message is too large: {len(payload)} bytes")
    frame = struct.pack("!I", len(payload)) + payload
    connection.sendall(frame)
    return len(frame)


def connect(host: str, port: int) -> socket.socket:
    connection = socket.create_connection((host, port), timeout=5)
    connection.settimeout(None)
    send_frame(connection, "@VENTUNO/1 CONFIG 0")
    print(f"[OK] connected to {host}:{port}", flush=True)
    return connection


def load_result(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or "yolo" not in value:
        raise ValueError("not an all_pipeline result JSON")
    return value


def main() -> int:
    args = parse_args()
    if args.once and not args.path.exists():
        raise SystemExit(f"path does not exist: {args.path}")
    if not args.path.exists():
        print(f"[INFO] waiting for pipeline output: {args.path}", flush=True)
    signatures: dict[Path, tuple[int, int]] = {}
    connection: socket.socket | None = None
    while True:
        pending: list[tuple[Path, tuple[int, int]]] = []
        for path in result_files(args.path):
            stat = path.stat()
            signature = (stat.st_mtime_ns, stat.st_size)
            if signatures.get(path) != signature:
                pending.append((path, signature))
        for path, signature in pending:
            try:
                data = load_result(path)
                message = format_result(data, path)
                if connection is None:
                    connection = connect(args.host, args.port)
                started = time.monotonic_ns()
                framed_bytes = send_frame(connection, message)
                elapsed_ns = max(time.monotonic_ns() - started, 1)
                payload_bytes = framed_bytes - 4
                send_frame(connection, f"@VENTUNO/1 STATS 0 {payload_bytes} {framed_bytes} {elapsed_ns}")
                signatures[path] = signature
                print(f"[TX] {path.name}: {payload_bytes} bytes", flush=True)
            except (ConnectionError, OSError, TimeoutError) as error:
                print(f"[WARN] connection failed: {error}; retrying", flush=True)
                if connection is not None:
                    connection.close()
                connection = None
                break
            except (json.JSONDecodeError, ValueError, OSError) as error:
                print(f"[WARN] skipped {path}: {error}", flush=True)
        if args.once:
            if connection is not None:
                connection.close()
            return 0
        time.sleep(args.poll_ms / 1000)


if __name__ == "__main__":
    raise SystemExit(main())
